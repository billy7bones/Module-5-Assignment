from sklearn.datasets import load_breast_cancer
import pandas as pd

# Load the dataset
cancer_data = load_breast_cancer()

# Convert data to a DataFrame
data = pd.DataFrame(data=cancer_data.data, columns=cancer_data.feature_names)
target = pd.Series(cancer_data.target, name="target")

# Combine data and target into one DataFrame
df = pd.concat([data, target], axis=1)

# Display basic dataset information
print("Dataset Shape:", df.shape)
print("First Few Rows:\n", df.head())
from sklearn.preprocessing import StandardScaler

# Standardize the feature data
scaler = StandardScaler()
scaled_data = scaler.fit_transform(data)

print("Scaled Data Shape:", scaled_data.shape)
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

# Apply PCA to reduce to 2 components
pca = PCA(n_components=2)
pca_result = pca.fit_transform(scaled_data)

# Convert PCA result to DataFrame
pca_df = pd.DataFrame(data=pca_result, columns=["PCA1", "PCA2"])
pca_df["target"] = target

# Display explained variance
explained_variance = pca.explained_variance_ratio_
print("Explained Variance by PCA Components:", explained_variance)

# Visualize PCA components
plt.figure(figsize=(10, 6))
colors = ['red', 'blue']
labels = ['Malignant', 'Benign']
for i, label in enumerate(labels):
    plt.scatter(
        pca_df.loc[pca_df["target"] == i, "PCA1"],
        pca_df.loc[pca_df["target"] == i, "PCA2"],
        c=colors[i],
        label=label,
        alpha=0.6
    )
plt.title("PCA Visualization (2 Components)")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.legend()
plt.grid()
plt.tight_layout()
plt.show()
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    pca_df[["PCA1", "PCA2"]], target, test_size=0.3, random_state=42
)

# Train logistic regression model
logreg = LogisticRegression()
logreg.fit(X_train, y_train)

# Make predictions
y_pred = logreg.predict(X_test)

# Evaluate the model
print("Accuracy Score:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
# Save classification report
report = classification_report(y_test, y_pred)
report_file = r"H:\My Drive\Nexford\MSc Business Analytics\Programming in R & Python - BAN6420\Module 5 - Data Manipulation in R and Python\Module 5 Assignment\PCA_classification_report.txt"

with open(report_file, "w") as f:
    f.write("Logistic Regression Classification Report\n")
    f.write("=" * 40 + "\n")
    f.write(report)

print(f"Classification report saved as {report_file}")
